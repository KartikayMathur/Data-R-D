# YouTube Channel Analyzer

A Python application that analyzes YouTube channels based on keywords and generates detailed reports.

## Features

- Search for top YouTube channels based on keywords
- Analyze video performance (views, likes)
- Download and store video thumbnails
- Generate detailed Excel reports
- User-friendly GUI interface
- Support for multiple browsers (Chrome, Firefox, Edge)
- Automatic requirements installation

## Installation

1. Clone or download this repository
2. Run the main script:
   ```bash
   python main.py
   ```
   The script will automatically:
   - Create necessary folders
   - Install required packages
   - Launch the GUI

## Requirements

All requirements will be automatically installed in the local directory. The main dependencies are:
- selenium
- webdriver_manager
- pandas
- Pillow
- requests
- PyQt6
- openpyxl
- beautifulsoup4

## Usage

1. Launch the application
2. Enter your search keyword
3. Select your preferred browser
4. Click "Start Analysis"
5. Wait for the analysis to complete
6. Click "Open Results" to view the generated report

## Project Structure

```
youtube_analyzer/
│
├── requirements.txt
├── main.py
├── config.py
├── README.md
│
├── src/
│   ├── __init__.py
│   ├── gui.py
│   ├── scraper.py
│   ├── analyzer.py
│   └── utils.py
│
├── requirements_installer/
│   └── install_requirements.py
│
├── data/
│   ├── spreadsheets/
│   └── thumbnails/
│
└── logs/
    └── app.log
```

## Notes

- The application uses browser automation, so please ensure you have a compatible browser installed
- Internet connection is required
- The analysis process may take several minutes depending on the number of videos
- All data is stored locally in the `data` directory

## Troubleshooting

If you encounter any issues:
1. Check the logs in `logs/app.log`
2. Ensure you have a stable internet connection
3. Try using a different browser
4. Make sure your browser is up to date

## License

This project is licensed under the MIT License.
