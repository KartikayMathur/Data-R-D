import os
import sys
import logging
import subprocess
import json
import time
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, List, Optional
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from PIL import Image, ImageTk
import requests
import threading

class RequirementsInstaller:
    """Handles the installation of all required dependencies."""
    
    REQUIRED_PACKAGES = [
        'selenium',
        'pandas',
        'Pillow',
        'openpyxl',
        'webdriver_manager'
    ]

    @staticmethod
    def check_and_install_requirements():
        logging.info("Checking and installing requirements...")
        for package in RequirementsInstaller.REQUIRED_PACKAGES:
            try:
                __import__(package)
            except ImportError:
                logging.info(f"Installing {package}...")
                subprocess.check_call([sys.executable, "-m", "pip", "install", package])

    @staticmethod
    def setup_project_structure():
        """Creates necessary directories for the project."""
        directories = [
            'data/spreadsheets',
            'data/thumbnails',
            'logs'
        ]
        for directory in directories:
            os.makedirs(directory, exist_ok=True)

class YouTubeAnalyzer:
    """Core functionality for YouTube channel analysis."""
    
    def __init__(self):
        self.driver = None
        self.wait = None
        self.setup_logging()
        
    def setup_logging(self):
        """Configures logging system."""
        logging.basicConfig(
            filename='logs/app.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def initialize_driver(self, browser_choice: str):
        """Initializes the selected web driver."""
        try:
            if browser_choice == "Chrome":
                options = webdriver.ChromeOptions()
                options.add_argument('--headless')
                self.driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
            elif browser_choice == "Firefox":
                options = webdriver.FirefoxOptions()
                options.add_argument('--headless')
                self.driver = webdriver.Firefox(executable_path=GeckoDriverManager().install(), options=options)
            
            self.wait = WebDriverWait(self.driver, 10)
            logging.info(f"Successfully initialized {browser_choice} driver")
        except Exception as e:
            logging.error(f"Failed to initialize driver: {str(e)}")
            raise

    def analyze_channel(self, keyword: str, progress_callback=None) -> Dict:
        """Analyzes YouTube channels based on the provided keyword."""
        try:
            self.driver.get(f"https://www.youtube.com/results?search_query={keyword}&sp=EgIQAg%253D%253D")
            time.sleep(2)  # Respect rate limiting
            
            channels_data = []
            channel_elements = self.wait.until(
                EC.presence_of_all_elements_located((By.CSS_SELECTOR, "ytd-channel-renderer"))
            )
            
            for idx, channel in enumerate(channel_elements[:10]):  # Analyze top 10 channels
                try:
                    channel_info = self._extract_channel_info(channel)
                    channels_data.append(channel_info)
                    if progress_callback:
                        progress_callback((idx + 1) * 10)
                except Exception as e:
                    logging.error(f"Error processing channel: {str(e)}")
                    continue
                
            return self._process_results(channels_data)
            
        except Exception as e:
            logging.error(f"Error in channel analysis: {str(e)}")
            raise

    def _extract_channel_info(self, channel_element) -> Dict:
        """Extracts information from a channel element."""
        return {
            'name': channel_element.find_element(By.CSS_SELECTOR, "#text").text,
            'subscribers': channel_element.find_element(By.CSS_SELECTOR, "#subscribers").text,
            'videos': self._get_channel_videos(channel_element.find_element(By.CSS_SELECTOR, "a").get_attribute("href"))
        }

    def _get_channel_videos(self, channel_url: str) -> List[Dict]:
        """Retrieves video information from a channel."""
        self.driver.get(f"{channel_url}/videos")
        time.sleep(2)  # Respect rate limiting
        
        videos = []
        video_elements = self.wait.until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, "ytd-grid-video-renderer"))
        )
        
        for video in video_elements[:5]:  # Analyze latest 5 videos
            try:
                video_info = {
                    'title': video.find_element(By.CSS_SELECTOR, "#video-title").text,
                    'views': video.find_element(By.CSS_SELECTOR, "#metadata-line span").text,
                    'url': video.find_element(By.CSS_SELECTOR, "#video-title").get_attribute("href"),
                    'thumbnail': video.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                }
                videos.append(video_info)
            except Exception as e:
                logging.error(f"Error extracting video info: {str(e)}")
                continue
                
        return videos

    def _process_results(self, channels_data: List[Dict]) -> Dict:
        """Processes and saves analysis results."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        excel_path = f"data/spreadsheets/analysis_{timestamp}.xlsx"
        
        # Create channel overview sheet
        channel_df = pd.DataFrame([{
            'Channel Name': channel['name'],
            'Subscribers': channel['subscribers'],
            'Videos Analyzed': len(channel['videos']),
            'Average Views': sum(int(''.join(filter(str.isdigit, video['views']))) 
                               for video in channel['videos']) / len(channel['videos'])
                               if channel['videos'] else 0
        } for channel in channels_data])
        
        # Create video details sheet
        video_data = []
        for channel in channels_data:
            for video in channel['videos']:
                video_data.append({
                    'Channel': channel['name'],
                    'Title': video['title'],
                    'Views': video['views'],
                    'URL': video['url']
                })
        video_df = pd.DataFrame(video_data)
        
        # Save to Excel
        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            channel_df.to_excel(writer, sheet_name='Channel Overview', index=False)
            video_df.to_excel(writer, sheet_name='Video Details', index=False)
            
        return {
            'excel_path': excel_path,
            'channels_analyzed': len(channels_data),
            'total_videos': sum(len(channel['videos']) for channel in channels_data)
        }

class YouTubeAnalyzerGUI:
    """Graphical user interface for the YouTube Analyzer."""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("YouTube Channel Analyzer")
        self.root.geometry("600x400")
        self.analyzer = YouTubeAnalyzer()
        self.setup_gui()
        
    def setup_gui(self):
        """Sets up the GUI components."""
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Keyword input
        ttk.Label(main_frame, text="Search Keyword:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.keyword_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=self.keyword_var, width=40).grid(row=0, column=1, columnspan=2, sticky=tk.W, pady=5)
        
        # Browser selection
        ttk.Label(main_frame, text="Browser:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.browser_var = tk.StringVar(value="Chrome")
        ttk.Combobox(main_frame, textvariable=self.browser_var, values=["Chrome", "Firefox"], state="readonly").grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        ttk.Progressbar(main_frame, length=400, variable=self.progress_var, mode='determinate').grid(row=2, column=0, columnspan=3, pady=10)
        
        # Analyze button
        ttk.Button(main_frame, text="Analyze", command=self.start_analysis).grid(row=3, column=0, columnspan=3, pady=10)
        
        # Results text
        self.results_text = tk.Text(main_frame, height=10, width=50)
        self.results_text.grid(row=4, column=0, columnspan=3, pady=10)
        
    def start_analysis(self):
        """Initiates the analysis process."""
        keyword = self.keyword_var.get().strip()
        if not keyword:
            messagebox.showerror("Error", "Please enter a keyword")
            return
            
        self.progress_var.set(0)
        threading.Thread(target=self._run_analysis, daemon=True).start()
        
    def _run_analysis(self):
        """Runs the analysis in a separate thread."""
        try:
            self.analyzer.initialize_driver(self.browser_var.get())
            results = self.analyzer.analyze_channel(self.keyword_var.get(), self.update_progress)
            
            self.results_text.delete(1.0, tk.END)
            self.results_text.insert(tk.END, f"""Analysis Complete!
Excel file saved: {results['excel_path']}
Channels analyzed: {results['channels_analyzed']}
Total videos analyzed: {results['total_videos']}""")
            
        except Exception as e:
            messagebox.showerror("Error", f"Analysis failed: {str(e)}")
        finally:
            if self.analyzer.driver:
                self.analyzer.driver.quit()
                
    def update_progress(self, value):
        """Updates the progress bar."""
        self.progress_var.set(value)
        
    def run(self):
        """Starts the GUI application."""
        self.root.mainloop()

def main():
    """Main entry point of the application."""
    try:
        # Setup phase
        RequirementsInstaller.check_and_install_requirements()
        RequirementsInstaller.setup_project_structure()
        
        # Launch GUI
        app = YouTubeAnalyzerGUI()
        app.run()
        
    except Exception as e:
        logging.error(f"Application error: {str(e)}")
        messagebox.showerror("Error", f"Application failed to start: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
