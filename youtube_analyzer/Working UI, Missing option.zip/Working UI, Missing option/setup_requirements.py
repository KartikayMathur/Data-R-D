import os
import sys
import subprocess
import json
from datetime import datetime
from pathlib import Path
import logging

class BootstrapRequirements:
    """Bootstrap installer for project requirements."""
    
    INITIAL_PACKAGES = [
        'setuptools',
        'wheel'
    ]
    
    MAIN_PACKAGES = {
        'selenium': '4.15.2',
        'pandas': '2.1.3',
        'Pillow': '10.1.0',
        'openpyxl': '3.1.2',
        'webdriver_manager': '4.0.1',
        'requests': '2.31.0',
        'beautifulsoup4': '4.12.2',
        'tk': '0.1.0'
    }

    def __init__(self):
        self.project_root = Path(__file__).parent
        self.req_folder = self.project_root / 'requirements'
        self.logs_folder = self.project_root / 'logs'
        self.packages_folder = self.req_folder / 'packages'
        self.setup_folders()
        self.setup_logging()

    def setup_folders(self):
        """Create necessary folders."""
        self.req_folder.mkdir(exist_ok=True)
        self.logs_folder.mkdir(exist_ok=True)
        self.packages_folder.mkdir(exist_ok=True)

    def setup_logging(self):
        """Initialize logging configuration."""
        logging.basicConfig(
            filename=self.logs_folder / 'requirements.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def install_bootstrap_packages(self):
        """Install initial required packages."""
        print("Installing bootstrap packages...")
        for package in self.INITIAL_PACKAGES:
            try:
                subprocess.run([
                    sys.executable,
                    '-m',
                    'pip',
                    'install',
                    '--upgrade',
                    package
                ], check=True)
                print(f"Successfully installed {package}")
            except subprocess.CalledProcessError as e:
                print(f"Error installing {package}: {str(e)}")
                logging.error(f"Failed to install {package}: {str(e)}")
                return False
        return True

    def install_main_packages(self):
        """Install main project packages."""
        print("\nInstalling main packages...")
        for package, version in self.MAIN_PACKAGES.items():
            try:
                package_spec = f"{package}=={version}"
                print(f"Installing {package_spec}")
                subprocess.run([
                    sys.executable,
                    '-m',
                    'pip',
                    'install',
                    package_spec
                ], check=True)
            except subprocess.CalledProcessError as e:
                print(f"Error installing {package}: {str(e)}")
                logging.error(f"Failed to install {package}: {str(e)}")
                return False
        return True

    def generate_requirements_files(self):
        """Generate requirements.txt and requirements.json."""
        # Generate requirements.txt
        requirements_txt = self.req_folder / 'requirements.txt'
        with open(requirements_txt, 'w') as f:
            for package, version in self.MAIN_PACKAGES.items():
                f.write(f"{package}=={version}\n")

        # Generate requirements.json
        requirements_json = self.req_folder / 'requirements.json'
        with open(requirements_json, 'w') as f:
            json.dump({
                'last_updated': datetime.now().isoformat(),
                'packages': self.MAIN_PACKAGES
            }, f, indent=4)

    def setup(self):
        """Run the complete setup process."""
        print("Starting requirements setup...")
        
        if not self.install_bootstrap_packages():
            print("Failed to install bootstrap packages. Check the logs for details.")
            return False

        if not self.install_main_packages():
            print("Failed to install main packages. Check the logs for details.")
            return False

        try:
            self.generate_requirements_files()
            print("\nGenerated requirements files successfully.")
        except Exception as e:
            print(f"Error generating requirements files: {str(e)}")
            logging.error(f"Failed to generate requirements files: {str(e)}")
            return False

        print("\nSetup completed successfully!")
        print(f"Requirements folder: {self.req_folder}")
        print(f"Logs folder: {self.logs_folder}")
        return True

def main():
    """Main entry point for the bootstrap installer."""
    try:
        installer = BootstrapRequirements()
        if installer.setup():
            print("\nAll requirements have been installed successfully.")
        else:
            print("\nSetup failed. Please check the logs for details.")
            sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        logging.error(f"Unexpected error during setup: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()